import React, {useEffect, useState } from 'react';
import base_url from '../api/phpapi';
import axios, * as others from 'axios';
import Blog from '../comps/Blog';
import Sidebar from '../comps/Sidebar';
import { Link } from 'react-router-dom';
import Insta from '../comps/Insta';
import { Helmet } from 'react-helmet';
import WorkShops from '../comps/WorkShops';
import InArticalAd from '../comps/InArticalAd';

 const  Home = () =>  {

	useEffect(()=> {
		getAllPostFromServer();
		getHomePagePost();
		
	},[]);

	var castories1 = {title:"",content:"",date:"",category:"",cat_id:"",thumb:""}

	const getAllPostFromServer =()=>{
		axios.get(`${base_url}\stories?mainstory`).then(
			(response)=>{
				console.log(response)
				setStories(response.data.CaStories);
				setNews(response.data.NewsUpdate);
				setPop(response.data.pop);
				setRecent(response.data.recent);
			},
			(error)=>{
				console.log(error);
			}
		)
	}

	const getHomePagePost =()=>{
		axios.get(`${base_url}\post?home_page_post`).then(
			(response)=>{
				setStory(response.data);
			},
			(error)=>{
				console.log(error);
			}
		)
	}

	const [castories,setStories] = useState([]);
	const [story,setStory] = useState([]);
	const [pop,setPop] = useState([]);
	const [recent,setRecent] = useState([]);
	const [news,setNews] = useState([]);
	
	
	if(castories.length>0){
		castories1 = castories[0];
	}

return (
        <>
	<Helmet>
	<title>Jobaaj Stories - Stories to make you fall in love with everything finance</title>
	<meta name="keyword" content="Jobaaj Stories, Ca Stories, People Stories, Public Figures, Jobaaj learnings"/>
	<meta 
	name="description"
	content="Jobaaj Stories is home to a plethora of content categorised in distinctive niches such as finance related news updates, inspirational stories about professionals and entrepreneurs in various domains, and global financial insights."/>
	</Helmet>
	<section id="hero">

		<div className="container-xl">

			<div className="row gy-4">

				<div className="col-lg-8">
					
					<div className="post featured-post-lg">
						<div className="details clearfix">
							<Link to={`/category/${story.cat_id}`} className="category-badge">{story.category}</Link>
							<h2 className="post-title"><Link to={`/${story.url}`}>{story.title}</Link></h2>
							<ul className="meta list-inline mb-0">
								<li className="list-inline-item"><Link to="/author">Jobaaj Stories</Link></li>
								<li className="list-inline-item">{story.date}</li>
							</ul>
						</div>
						<Link to={`/${story.url}`}>
							<div className="thumb rounded">
								<div className="inner data-bg-image" data-bg-image={story.thumb} style={{ backgroundImage:`url(${story.thumb})`}}></div>
							</div>
						</Link>
					</div>

				</div>

				<div className="col-lg-4">

					<div className="post-tabs rounded bordered">
						<ul className="nav nav-tabs nav-pills nav-fill" id="postsTab" role="tablist">
							<li className="nav-item" role="presentation"><button aria-controls="popular" aria-selected="true" style={{textAlign:"center"}} className="nav-link active" data-bs-target="#popular" data-bs-toggle="tab" id="popular-tab" role="tab" type="button">Popular</button></li>
							<li className="nav-item" role="presentation"><button aria-controls="recent" aria-selected="false" style={{textAlign:"center"}}  className="nav-link" data-bs-target="#recent" data-bs-toggle="tab" id="recent-tab" role="tab" type="button">Recent</button></li>
						</ul>
						<div className="tab-content" id="postsTabContent">
							<div className="lds-dual-ring"></div>
							<div aria-labelledby="popular-tab" className="tab-pane fade show active" id="popular" role="tabpanel">
								
								{
									pop.length>0 ? pop.map((item) => <Blog key={item.id} blog={item} type={4}/>)
									: "No Post"
								}
							
							</div>
							<div aria-labelledby="recent-tab" className="tab-pane fade" id="recent" role="tabpanel">
								{
									recent.length>0 ? recent.map((item) => <Blog key={item.id} blog={item} type={4}/>)
									: "No Post"
								}
							</div>
						</div>
					</div>
				</div>

			</div>

		</div>

	</section>

	<section className="main-content">
		<div className="container-xl">
			<div className="row gy-4">
				<div className="col-lg-8">

					<div className="section-header">
						<h3 className="section-title">Corporate speaks</h3>
						<img src="assets/images/wave.svg" className="wave" alt="wave" />
					</div>

					<div className="padding-30 rounded bordered">
						<div className="row gy-5">
							<div className="col-sm-6">
								
								<div className="post">
									<div className="thumb rounded">
										<Link to={`/category/${castories1.cat_id}`} className="category-badge position-absolute">{castories1.category}</Link>
										<span className="post-format">
											<i className="icon-picture"></i>
										</span>
										<Link to={`/${castories1.url}`}>
											<div className="inner">
												<img src={castories1.thumb} alt="post-title" />
											</div>
										</Link>
									</div>
									<ul className="meta list-inline mt-4 mb-0">
										<li className="list-inline-item"><Link to="/author"><img src="assets/images/favicon.png" className="author" alt="author"/>Jobaaj Stories</Link></li>
										<li className="list-inline-item">{castories1.date}</li>
									</ul>
									<h5 className="post-title mb-3 mt-3"><Link to={`/${castories1.url}`}>{castories1.title}</Link></h5>
									<p className="excerpt mb-0">{castories1.content}</p>
								</div>
							</div>
							<div className="col-sm-6">
								{
									castories.length>0 ? castories.slice(1).map((item) => <Blog key={item.id} blog={item} type={0}/>)
									: "No Post"
								}
							
							</div>
						</div>
					</div>

					<div className="spacer" data-height="50"></div>

					<div className="ads-horizontal text-md-center">
					
					</div>

					<InArticalAd slot="1363350575"/> 

					<div className="spacer" data-height="50"></div>

					<div style={{marginTop:"20px"}} className="section-header">
						<h3 className="section-title">Startups on fire</h3>
						<img src="assets/images/wave.svg" className="wave" alt="wave" />
					</div>

					<div className="padding-30 rounded bordered">
						<div className="row gy-5">
								{
									news.length>0 ? news.slice(0,2).map((item) => <Blog key={item.id} blog={item} type={1}/>)
									: "No Post"
								}
						</div>

							<div className='row'>
								{
									news.length>0 ? news.slice(2,6).map((item) => <Blog key={item.id}  blog={item} type={2}/>)
									: "No Post"
								}
							</div>
					</div>

					<div className="spacer" data-height="50"></div>

					<WorkShops/>

					{/* <div className="section-header">
						<h3 style={{marginTop:"20px"}} className="section-title">Quaterly Results</h3>
						<img src="assets/images/wave.svg" className="wave" alt="wave" />
						<div className="slick-arrows-top">
							<button type="button" data-role="none" className="carousel-topNav-prev slick-custom-buttons" aria-label="Previous"><i className="icon-arrow-left"></i></button>
							<button type="button" data-role="none" className="carousel-topNav-next slick-custom-buttons" aria-label="Next"><i className="icon-arrow-right"></i></button>
						</div>
					</div>

					<div className="row post-carousel-twoCol post-carousel">
						
						<div className="post post-over-content col-md-6">
							<div className="details clearfix">
								<a href="category.html" className="category-badge">Inspiration</a>
								<h4 className="post-title"><a href="blog-single.html">Want To Have A More Appealing Tattoo?</a></h4>
								<ul className="meta list-inline mb-0">
									<li className="list-inline-item"><a href="#">Katen Doe</a></li>
									<li className="list-inline-item">29 March 2021</li>
								</ul>
							</div>
							<a href="blog-single.html">
								<div className="thumb rounded">
									<div className="inner">
										<img src="assets/imagess/inspiration-1.jpg" alt="thumb" />
									</div>
								</div>
							</a>
						</div>
						<div className="post post-over-content col-md-6">
							<div className="details clearfix">
								<a href="category.html" className="category-badge">Inspiration</a>
								<h4 className="post-title"><a href="blog-single.html">Want To Have A More Appealing Tattoo?</a></h4>
								<ul className="meta list-inline mb-0">
									<li className="list-inline-item"><a href="#">Katen Doe</a></li>
									<li className="list-inline-item">29 March 2021</li>
								</ul>
							</div>
							<a href="blog-single.html">
								<div className="thumb rounded">
									<div className="inner">
										<img src="assets/imagess/inspiration-1.jpg" alt="thumb" />
									</div>
								</div>
							</a>
						</div>
						<div className="post post-over-content col-md-6">
							<div className="details clearfix">
								<a href="category.html" className="category-badge">Inspiration</a>
								<h4 className="post-title"><a href="blog-single.html">Want To Have A More Appealing Tattoo?</a></h4>
								<ul className="meta list-inline mb-0">
									<li className="list-inline-item"><a href="#">Katen Doe</a></li>
									<li className="list-inline-item">29 March 2021</li>
								</ul>
							</div>
							<a href="blog-single.html">
								<div className="thumb rounded">
									<div className="inner">
										<img src="assets/imagess/inspiration-1.jpg" alt="thumb" />
									</div>
								</div>
							</a>
						</div>
						
					</div> */}

					<div className="spacer" data-height="50"></div>

					<div className="section-header">
						<h3 className="section-title">Learn something new</h3>
						<img src="assets/images/wave.svg" className="wave" alt="wave" />
					</div>

					<div className="padding-30 rounded bordered">

						<div className="row">
								{
									news.length>0 ? news.slice(1,6).map((item) => <Blog key={item.id} blog={item} type={3}/>)
									: "No Post"
								}
							
						</div>
						{/* <div className="text-center">
							<button className="btn btn-simple">Load More</button>
						</div> */}

					</div>

				</div>
				<Sidebar/>
			</div>

		</div>
	</section>

	<Insta/>
        </>
      )
}

export default Home;