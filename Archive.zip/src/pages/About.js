import React, { Component } from "react";
import { Link } from "react-router-dom";
import Insta from "../comps/Insta";
import Sidebar from "../comps/Sidebar";


class About extends Component {

    render(){
        return (
            <>
              <div className="main-content mt-3">
            <div className="container-xl">
            <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item"><Link to="/">Home</Link></li>
                     <li className="breadcrumb-item active" aria-current="page">Author</li> 
                </ol>
            </nav>
            <div className="row gy-4">

                <div className="col-lg-8">
                <h2>About the Author</h2>
            <p className="mb-4">As a team effort, we at Jobaaj Stories strive to report credible, fresh, and applicable finance news to enrich, inform, and educate our audience, i.e, you!</p>
         
                        
                      
                


                  <div className="spacer" data-height="50"></div>

                    <div className="spacer" data-height="50"></div>

                   
                </div>

                <Sidebar/>

            </div>
                    <Insta/>
            </div>
        </div>
        
        
            </>


        )
    }
}

export default About;