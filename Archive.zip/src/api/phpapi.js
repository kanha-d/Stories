const base_url = "https://stories.jobaaj.com/files/api/";
export default base_url;