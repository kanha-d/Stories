import React from "react";

const Insta = () => {
    return (
        <>
          {/* <div className="instagram">
                <div className="container-xl">
                
                    <a href="https://www.instagram.com/jobaajstories/" className="btn btn-default btn-instagram">@Jobaajstories on Instagram</a>
                    <div className="instagram-feed d-flex flex-wrap">
                        <div className="insta-item col-sm-2 col-6 col-md-2">
                            <a href="#">
                                <img src={process.env.REACT_APP_URL + "assets/images/insta/insta-1.jpg"} alt="insta-title" />
                            </a>
                        </div>
                        <div className="insta-item col-sm-2 col-6 col-md-2">
                            <a href="#">
                                <img src={process.env.REACT_APP_URL + "assets/images/insta/insta-1.jpg"} alt="insta-title" />
                            </a>
                        </div>
                        <div className="insta-item col-sm-2 col-6 col-md-2">
                            <a href="#">
                                <img src={process.env.REACT_APP_URL + "assets/images/insta/insta-1.jpg"} alt="insta-title" />
                            </a>
                        </div>
                        <div className="insta-item col-sm-2 col-6 col-md-2">
                            <a href="#">
                                <img src={process.env.REACT_APP_URL + "assets/images/insta/insta-1.jpg"} alt="insta-title" />
                            </a>
                        </div>
                        <div className="insta-item col-sm-2 col-6 col-md-2">
                            <a href="#">
                                <img src={process.env.REACT_APP_URL + "assets/images/insta/insta-1.jpg"} alt="insta-title" />
                            </a>
                        </div>
                        <div className="insta-item col-sm-2 col-6 col-md-2">
                            <a href="#">
                                <img src={process.env.REACT_APP_URL + "assets/images/insta/insta-1.jpg"} alt="insta-title" />
                            </a>
                        </div>
                    </div>
                </div>
            </div>

          */}

            </>
    )
}
export default Insta;