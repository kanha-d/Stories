import React, { useState,useEffect } from 'react'
import { Link } from 'react-router-dom';

const Head = ()  => {

    useEffect(()=>{ 
    });

    return(
         <>
            {/* <div className="main-overlay"></div> */}
         </>
        )
}
 
export default Head;