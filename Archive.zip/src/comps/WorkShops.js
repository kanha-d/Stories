import React from 'react'
import Wshop from './Wshop';


const workshops = [
    {
        title:"Stock Market / Trading",
        cat:"3 Days Option Trading Workshop",
        desc : "Learn Option Secrets That No Full time trader Wants You To Know to start your Profitable Option trading Journey. Even If the markets moves up, down And sideways.",
        url:"https://go.jobaaj.com/option-trading-workshop",
        img:"https://www.jobaajlearnings.com/data/thumb/545thumb-course.jpg"
    },
    {
        title:"Data Science",
        cat:"5 Days Kickstarter Data Science Workshop",
        desc : "Learn Data Analysis Using Python, SQL And Power Bi without Any Prior Experience and without Spending Lakhs In Expensive Degrees.",
        url:"https://go.jobaaj.com/tableau-workshop-p1",
        img:"https://www.jobaajlearnings.com/data/thumb/35.png"
    },
    {
        title:"Finance",
        cat:"Financial Modelling Workshop",
        desc : "Learn Financial Modelling and become a Financial Modelling Expert and get a dream job in Finance",
        url:"https://go.jobaaj.com/financial_modelling",
        img:"https://www.jobaajlearnings.com/data/thumb/149thumb-course.jpg"
    },
    {
        title:"Data Analytics",
        cat:"2 Days Data Analytics Workshop",
        desc : "Become a Highly Paid Data Scientist In no Time . Learn your path in data analytics to achieve a 6 figure job even without any coding experience.",
        url:"https://go.jobaaj.com/option-trading-workshophttps://go.jobaaj.com/2-days-data-science-masterclass",
        img:"https://www.jobaajlearnings.com/data/thumb/28.png"
    },
    {
        title:"Management",
        cat:"2 days Management Consulting Workshop",
        desc : "Learn how to build professional strategic frameworks and crack case interviews and build a successful career as a Management consultant.",
        url:"https://go.jobaaj.com/2-days-data-science-masterclass",
        img:"https://www.jobaajlearnings.com/data/thumb/628thumb-course.jpg"
    }
]


const WorkShops = () => {
  return (
   <>
   <div style={{marginTop:"20px"}} className="section-header">
						<h3 className="section-title">RUNNING <span style={{color:"#ff5e75"}}>FREE </span>⚡ WORKSHOPS ️</h3>
						<img src="assets/images/wave.svg" className="wave" alt="wave" />
					</div>

                <div className="padding-30 rounded bordered">
                     <div className="row gy-5">
                     {
                        workshops.length>0 ? workshops.map((item) => <Wshop key={item.id} work={item}/>)
                        : "No Workshops "
                    }
                </div>

						
                </div>

                <div className="spacer" data-height="50"></div>

   </>
  )
}


export default WorkShops;
