import React from "react";
import { Link } from "react-router-dom";

const Blog = ({blog,type}) => {

    const getImageError = e => { 
        e.currentTarget.src = "../assets/images/placeholder.jpg";
    }
    if(type==0) {
    return(
        <>
        <div className="post post-list-sm square">
            <div className="thumb rounded">
              <Link to={`/${blog.url}`}>
                    <div className="inner">
                        <img src={blog.thumb}  onError={getImageError} alt="post-title" />
                    </div>
              </Link>
            </div>
            <div className="details clearfix">
                <h6 className="post-title my-0"><Link to={`/${blog.url}`}>{blog.title}</Link></h6>
                <ul className="meta list-inline mt-1 mb-0">
                    <li className="list-inline-item">{blog.date}</li>
                </ul>
            </div>
        </div>
        </>
      )
    }
    else if(type==1){ 
        return (
        <>
            <div className="col-sm-6">
                    <div className="post">
                        <div className="thumb rounded">
                        <Link to={`/category/${blog.cat_id}`} className="category-badge position-absolute">{blog.category}</Link>
                            <span className="post-format">
                                <i className="icon-earphones"></i>
                            </span>
                            <Link to={`/${blog.url}`}>
                                <div className="inner">
                                    <img src={blog.thumb} onError={getImageError} alt="post-title" />
                                </div>
                            </Link>
                        </div>
                        <ul className="meta list-inline mt-4 mb-0">
                            <li className="list-inline-item"><Link to="/author"><img src="assets/images/favicon.png" className="author" alt="author"/>Jobaaj Stories</Link></li>
                            <li className="list-inline-item">{blog.date}</li>
                        </ul>
                        <h5 className="post-title mb-3 mt-3"><Link to={`/${blog.url}`}>{blog.title}</Link></h5>
                        <p className="excerpt mb-0">{blog.content}</p>
                    </div>
            </div>
        </>
        )
    }else if(type==2){
        return (
            <>
               <div className='col-sm-6'>
                    <div className="post post-list-sm square before-seperator">
                        <div className="thumb rounded">
                            <Link to={`/${blog.url}`}>
                                <div className="inner">
                                    <img src={blog.thumb} onError={getImageError} alt="post-title" />
                                </div>
                            </Link>
                        </div>
                        <div className="details clearfix">
                            <h6 className="post-title my-0"><Link to={`/${blog.url}`}>{blog.title}</Link></h6>
                            <ul className="meta list-inline mt-1 mb-0">
                                <li className="list-inline-item">{blog.date}</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </>
            )
    }else if(type==3){
        return(
            <>
           <div className="col-md-12 col-sm-6">
								
								<div className="post post-list clearfix">
									<div className="thumb rounded">
										<span className="post-format-sm">
											<i className="icon-picture"></i>
										</span>
										<Link to={`/${blog.url}`}>
											<div className="inner">
												<img src={blog.thumb} onError={getImageError} alt="post-title" />
											</div>
										</Link>
									</div>
									<div className="details">
										<ul className="meta list-inline mb-3">
											<li className="list-inline-item"><Link to="/author"><img src={process.env.REACT_APP_URL + "assets/images/favicon.png"} className="author" alt="author"/>Jobaaj Stories</Link></li>
											<li className="list-inline-item"><Link to={`/category/${blog.cat_id}`}>{blog.category}</Link></li>
											<li className="list-inline-item">{blog.date}</li>
										</ul>
										<h5 className="post-title"><Link to={`/${blog.url}`}>{blog.title}</Link></h5>
										<p className="excerpt mb-0">{blog.content}</p>
									
									</div>
								</div>
							</div>
            </>
        )
    } else if(type==4) {
        return(
            <>
            	<div className="post post-list-sm circle">
                        <div className="thumb circle">
                            <Link to={`/${blog.url}`}>
                                <div className="inner">
                                    <img style={{"height" : "56px"}} src={blog.thumb} onError={getImageError} alt="post-title" />
                                </div>
                            </Link>
                        </div>
                        <div className="details clearfix">
                            <h6 style={{"fontSize":"12px"}} className="post-title my-0"><Link to={`/${blog.url}`}>{blog.title}</Link></h6>
                            <ul className="meta list-inline mt-1 mb-0">
                                <li className="list-inline-item">{blog.date}</li>
                            </ul>
                        </div>
                </div>
                </>
        )
    }else {
        return (
            <>
             <div className="col-sm-6">
                    <div className="post post-grid rounded bordered">
                        <div className="thumb top-rounded">
                        <Link to={`/category/${blog.cat_id}`} className="category-badge position-absolute">{blog.category}</Link>
                            <span className="post-format">
                                <i className="icon-picture"></i>
                            </span>
                            <Link to={`/${blog.url}`}>
                                <div className="inner">
                                    <img src={blog.thumb}  onError={getImageError} alt="post-title" />
                                </div>
                            </Link>
                        </div>
                        <div className="details">
                            <ul className="meta list-inline mb-0">
                                <li className="list-inline-item"><Link to="/author"><img src={process.env.REACT_APP_URL + "assets/images/favicon.png"}  className="author" alt="author"/>Jobaaj Stories</Link></li>
                                <li className="list-inline-item">{blog.date}</li>
                            </ul>
                            <h5 className="post-title mb-3 mt-3"><Link to={`/${blog.url}`}>{blog.title}</Link></h5>
                            <p className="excerpt mb-0">{blog.content}</p>
                        </div>
                      
                    </div>
                </div>
            </>
        )
    }
}
export default Blog;